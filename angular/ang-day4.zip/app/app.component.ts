import { Component } from 'angular2/core';
import { ProductListComponent } from './products/product-list.component'
//import statements

//metadata
@Component({
    selector:'pm-app',
    //inline (using single quotes) or multiline (using backtick) template
    template:`<br>First simple 
    <b> component </b> <br>
    {{pageTitle}}<br>
    <pm-products></pm-products>`,
    directives: [ProductListComponent]
})
//{{}} is data binding - one way binding

//similar to java class "public class AppComponent{..}"
export class AppComponent{
    pageTitle:string='Acme Product Management';

}