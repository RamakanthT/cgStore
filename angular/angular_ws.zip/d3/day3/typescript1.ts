var myName:string = "Ramakanth";
var myAge:number = 27;
var canVote:boolean = true;
var anything:any="Capgemini";

const PI=3.14;
//PI=22;
document.write("<br>PI is a "+typeof(PI)+" "+PI);

interface SuperHero{
realName:String;
superName:String;
}

var superman:SuperHero={
realName:"Amitabh Bacchan",
superName:"Super Man"
}

document.write("<br><br>"+superman.realName+" is "+superman.superName);

var superHeros:SuperHero[]=[];
superHeros.push({realName:"Gangadhar",superName:"Shaktimaan"});

document.write("<br><br>"+superHeros[0].realName+" is "+superHeros[0].superName);
var aVariable=123;
if(true){
var aVariable=999;
}
document.write("<br><br> using var: "+aVariable);

var numbers = [1,4,9];
var roots=numbers.map(Math.sqrt);
console.log("roots is: "+roots);

var getSum=function(num1:number,num2:number):number
{
return num1+num2;
}

var sumls:number = getSum(2,2);
document.write("<br><br>Sum is "+sumls);

var total = [0,1,2,3].reduce(function(a,b){return a+b;});
document.write("<br>total is :"+total);

var total1 = [0,1,2,3].reduce((a,b)=>a+b);
document.write("<br>total1 is :"+total1);

var addOne=(x)=>x+1;
document.write("<br>add one: "+addOne(21));

var sumAll=function(...nums:number[]):void
{
var sum=nums.reduce((a,b)=>a+b);//fat arrow
document.write("<br>sum is"+sum);
}
sumAll(2,2,2,2);

sumAll(2,2,3,2,2);