var myName = "Ramakanth";
var myAge = 27;
var canVote = true;
var anything = "Capgemini";
var PI = 3.14;
//PI=22;
document.write("<br>PI is a " + typeof (PI) + " " + PI);
var superman = {
    realName: "Amitabh Bacchan",
    superName: "Super Man"
};
document.write("<br><br>" + superman.realName + " is " + superman.superName);
var superHeros = [];
superHeros.push({ realName: "Gangadhar", superName: "Shaktimaan" });
document.write("<br><br>" + superHeros[0].realName + " is " + superHeros[0].superName);
var aVariable = 123;
if (true) {
    var aVariable = 999;
}
document.write("<br><br> using var: " + aVariable);
var numbers = [1, 4, 9];
var roots = numbers.map(Math.sqrt);
console.log("roots is: " + roots);
var getSum = function (num1, num2) {
    return num1 + num2;
};
var sumls = getSum(2, 2);
document.write("<br><br>Sum is " + sumls);
var total = [0, 1, 2, 3].reduce(function (a, b) { return a + b; });
document.write("<br>total is :" + total);
var total1 = [0, 1, 2, 3].reduce(function (a, b) { return a + b; });
document.write("<br>total1 is :" + total1);
var addOne = function (x) { return x + 1; };
document.write("<br>add one: " + addOne(21));
var sumAll = function () {
    var nums = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        nums[_i] = arguments[_i];
    }
    var sum = nums.reduce(function (a, b) { return a + b; }); //fat arrow
    document.write("<br>sum is" + sum);
};
sumAll(2, 2, 2, 2);
sumAll(2, 2, 3, 2, 2);
